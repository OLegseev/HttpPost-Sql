﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Net.Http;



namespace ImagePost
{

    //интерфейс для реализации классами post
    public interface IImagePost
    {
        void Post(IImageConverter imageConverter);
    }
    //интерфейс для реализации классами convert
    public interface IImageConverter
    {
        string ImageConvert();
    }
    //класс для отправки картнинки на сайт
    public class HttpPost : IImagePost
    {
        private readonly string _apiUrl = "https://httpbin.org/post";

        public async void Post(IImageConverter imageConverter)
        {
            try
            {
                //метод получает экземпляр класса который реализует интерфейс IImageConverter
                //и обращается к методу ImageConvert() который возвращает ссылку на изображение.jpg
                string imagePath = imageConverter.ImageConvert();
                //преобразование картинки в base64
                byte[] imageBytes = File.ReadAllBytes(imagePath);
                string base64Image = Convert.ToBase64String(imageBytes);

                using (var client = new HttpClient())
                {
                    //отправка запроса Http
                    var requestData = new { image = base64Image };
                    var json = Newtonsoft.Json.JsonConvert.SerializeObject(requestData);
                    var content = new StringContent(json, Encoding.UTF8, "application/json");

                    // получение текста от сайта
                    var response = await client.PostAsync(_apiUrl, content);
                    
                    var responseText = await response.Content.ReadAsStringAsync();
                    var statusCode = (int)response.StatusCode;
                    //сохранение ответа в файл
                    File.WriteAllText("response.json", responseText);
                    File.WriteAllText("status_code.txt", statusCode.ToString());

                    Console.WriteLine($"Ответ сохранен в файлах: response.json и status_code.txt");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при отправке POST-запроса. Подробнее в LogFile.txt");
                Logger logger = new Logger();
                logger.Log($"Ошибка при отправке POST-запроса: {ex.Message}");
            }
        }
    }
    //класс для конвертиртации картинки из png в jpg
    public class PngConverter : IImageConverter
    {
        private string _path;
        //запись ссылки на картинку
        public PngConverter(string imagePath)
        {
            _path = imagePath;
        }
        //метод для конвертации картинки
        public string ImageConvert()
        {
           //Получение нового имени картинки
            string imageJpgPath = Path.GetDirectoryName(_path) + "\\" + Path.GetFileNameWithoutExtension(_path) + "ToJpg.jpg";
            try
            {
                //преобразование картинки в jpg
                using (Bitmap pngImage = new Bitmap(_path))
                {
                    ImageCodecInfo jpgEncoder = GetEncoder(ImageFormat.Jpeg);
                    System.Drawing.Imaging.Encoder myEncoder = System.Drawing.Imaging.Encoder.Quality;
                    EncoderParameters myEncoderParameters = new EncoderParameters(1);
                    EncoderParameter myEncoderParameter = new EncoderParameter(myEncoder, 90L);

                    myEncoderParameters.Param[0] = myEncoderParameter;
                    //сохранение картинки в ту же деррикторию 
                    pngImage.Save(imageJpgPath, jpgEncoder, myEncoderParameters);
                }
                Console.WriteLine("Изображение успешно конвертировано в формат JPG.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при конвертации изображения. Подробнее в LogFile.txt ");
                Logger logger = new Logger();
                logger.Log($"Ошибка при конвертации изображения: {ex.Message}");
            }
            return imageJpgPath;
        }
        //получение кодека
        private static ImageCodecInfo GetEncoder(ImageFormat format)
        {
            try
            {
                ImageCodecInfo[] codecs = ImageCodecInfo.GetImageDecoders();
                foreach (ImageCodecInfo codec in codecs)
                {
                    if (codec.FormatID == format.Guid)
                    {
                        return codec;
                    }
                }
                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при получении кодека. Подробнее в LogFile.txt ");
                Logger logger = new Logger();
                logger.Log($"Ошибка при получении кодека: {ex.Message}");
            }
            return null;
        }
    }
    //класс для конвертиртации картинки из bmp в jpg
    public class BmpConverter : IImageConverter
    {
        private string _path;

        public BmpConverter(string imagePath)
        {
            _path = imagePath;
        }

        public string ImageConvert()
        {

            string imageJpgPath = Path.GetDirectoryName(_path) +"\\" +Path.GetFileNameWithoutExtension(_path) +"ToJpg.jpg";
            try
            {
                
                Bitmap bmpImage = new Bitmap(_path);
                ImageCodecInfo jpgEncoder = GetEncoder(ImageFormat.Jpeg);
                //создаем параметры для сохранения с разными уровнями качества
                EncoderParameters encoderParameters = new EncoderParameters(1);
                EncoderParameter encoderParameter;
                //устанавливаем уровень качества (от 0 до 100)
                encoderParameter = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 90L); // Например, 90%
                encoderParameters.Param[0] = encoderParameter;

                //сохраняем изображение
                bmpImage.Save(imageJpgPath, jpgEncoder, encoderParameters);

                Console.WriteLine("Изображение успешно конвертировано в JPG.");

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при конвертации изображения. Подробнее в LogFile.txt ");
                Logger logger = new Logger();
                logger.Log($"Ошибка при конвертации изображения: {ex.Message}");
            }
            return imageJpgPath;
        }
        
        private static ImageCodecInfo GetEncoder(ImageFormat format)
        {
            try
            {
                ImageCodecInfo[] codecs = ImageCodecInfo.GetImageEncoders();
                foreach (ImageCodecInfo codec in codecs)
                {
                    if (codec.FormatID == format.Guid)
                    {
                        return codec;
                    }
                }
                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при получении кодека. Подробнее в LogFile.txt ");
                Logger logger = new Logger();
                logger.Log($"Ошибка при получении кодека: {ex.Message}");
            }
            return null;
        }
    }
    //класс для записи логов
    public class Logger
    {
        public void Log(string message)
        {
            try
            {
                //запись ллогов в файл
                File.AppendAllText("LogFile.txt", $"{DateTime.Now}: {message}\n\n");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при записи лога: {ex.Message}");
            }
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Введите путь к вашему изображению");
                string imagePath = Console.ReadLine();
                IImagePost imagePost = new HttpPost();
                imagePost.Post(new PngConverter(imagePath));

                //imagePost.Post(new BmpConverter(imagePath));


                //класс BmpConverter реализован для демонстрации
                //использования полиморфизма и возможности 
                //программы к расширению функционала(он тоже работает)




            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при получении пути. Подробнее в LogFile.txt ");
                Logger logger = new Logger();
                logger.Log($"Ошибка при получении пути: {ex.Message}");
            }

            Console.ReadKey();
        }
    }
}
